<?php 
	echo json_encode( ini_get( 'upload_max_filesize' ) ); 
?>	
